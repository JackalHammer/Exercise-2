## weatherapp.js ## 
Load live weather for a given location from openweathermap api https://openweathermap.org/current

Use the following id names on target element to be populated with each weather value:
* id="humidity"
* id="wind"
* id="maxtemp"
* id="mintemp"
* id="temp"
* id="description"

location: option to update location variable to string with other location.

